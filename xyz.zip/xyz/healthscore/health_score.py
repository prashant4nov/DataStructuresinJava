#!/usr/bin/env python
import json
import logging
import datetime
import pandas as pd
import numpy as np
import math
import datetime
from datetime import datetime, timedelta


class HealthScore(object):

    CATEGORY_MAP = {
        "Running": "Vigorous",
        "Walking": "Moderate",
        "Sports": "Vigorous",
        "Aerobic Training": "Vigorous",
        "Weight Training": "Muscle Strenghtening",
        "Bicycling": "Vigorous"
        }

    def getAge(self, monthEvaluation, monthBirth, dayEvaluation,
               dayBirth, yearEvaluation, yearBirth):
        print "age:::"
        print "montheval::"
        print monthEvaluation
        print "monthBirth::"
        print monthBirth
        print "dayeval::"
        print dayEvaluation
        print "dayBirth:::"
        print dayBirth
        print "yeareval::"
        print yearEvaluation
        print "yearBirth:::"
        print yearBirth

        if monthEvaluation < monthBirth or (monthEvaluation ==
           monthBirth and dayEvaluation < dayBirth):
            return (yearEvaluation - yearBirth) - 1
        else:
            return (yearEvaluation - yearBirth)

    def getEarliestDate(self, joinDate, evaluationDate):
        print "joinDate:"
        print joinDate

        print "evaluationDate:"
        print evaluationDate

        maxDays = 24

        print "evaluationDate - -- "
        print evaluationDate - timedelta(days=maxDays)

        return max(joinDate, evaluationDate -
                   timedelta(days=maxDays))


    def weeks(self, evaluationDate, earliestDate):
        print "evaluationDate:"
        print evaluationDate

        print "earliestDate:"
        print earliestDate


        minimumDays = 7
        weeks = 1
        diff = evaluationDate - earliestDate

        print "diff:"
        print diff


        if diff.days < minimumDays:
            weeks = 0
            # return "Insufficient Data - minimum 7 days required"
        else:
            weeks = diff.days / minimumDays
        return weeks

    def aerobicSeg(self, activity_category):
        if activity_category in self.CATEGORY_MAP.keys():
            return self.CATEGORY_MAP[activity_category]
        return 0

    def muscleSeg(self, activity_category):
        if activity_category in self.CATEGORY_MAP.keys():
            return self.CATEGORY_MAP[activity_category]
        return 0

    def getModerate(self, age, pregnancy, condition):
        moderateMap1 = {
            1: 1.0,
            2: 150.0,
            3: 250.0,
            4: 400.0
        }

        moderateMap2 = {
            1: 1.0,
            2: 60.0,
            3: 150.0,
            4: 300.0
        }
        print "moderate:condition"
        print condition
        print "moderate:pregnancy"
        print pregnancy
        print "moderate:age::"
        print age
     
        if 18 < age and age < 65 and pregnancy is False:
            print "moderate:if::"
            return moderateMap1[condition]
        elif age > 65 or pregnancy is True:
            print "moderate:else::"
            return moderateMap2[condition]

    def getVigorous(self, age, pregnancy, condition):
        vigorousMap1 = {
            1: 1.0,
            2: 60.0,
            3: 75.0,
            4: 160.0
        }

        vigorousMap2 = {
            1: 1.0,
            2: 30.0,
            3: 90.0,
            4: 150.0
        }

        if 18 < age and age < 65 and pregnancy is False:
            return vigorousMap1[condition]
        elif age > 65 or pregnancy is True:
            return vigorousMap2[condition]

    def muscleStrengthening(self, age, pregnancy, condition):
        muscleMap1 = {
            1: 1,
            2: 1,
            3: 2,
            4: 3
        }

        muscleMap2 = {
            1: 1,
            2: 1,
            3: 2,
            4: 3
        }

        if 18 < age and age < 65 and pregnancy is False:
            return muscleMap1[condition]
        elif age > 65 or pregnancy is True:
            return muscleMap2[condition]

    def getScoreI(self, age, pregnancyStatus, moderatePerWeek, vigorousPerWeek):
            print age
            print type(age)
            print pregnancyStatus
            print type(pregnancyStatus)
            print moderatePerWeek
            print type(moderatePerWeek)
            print vigorousPerWeek
            print type(vigorousPerWeek)

            moderate = self.getModerate(age, pregnancyStatus, 4)
            vigorous = self.getVigorous(age, pregnancyStatus, 4)

            print "moderate>>"
            print moderate
            print type(moderate)
            print vigorous
            print type(vigorous)
            value = (vigorousPerWeek/moderate) + (moderatePerWeek/vigorous)

            print "value>>"
            print value
            if value >= 1:
                return 4
            else:
                for i in range(1, 4):
                    moderate = self.getModerate(age, pregnancyStatus, i)
                    vigorous = self.getVigorous(age, pregnancyStatus, i)
                    value1 = (vigorousPerWeek/moderate) + \
                             (moderatePerWeek/vigorous)

                    moderate = self.getModerate(age, pregnancyStatus, i+1)
                    vigorous = self.getVigorous(age, pregnancyStatus, i+1)
                    value2 = (vigorousPerWeek/moderate) + \
                             (moderatePerWeek/vigorous)

                    print "values:"
                    print value1
                    print type(value1)
                    print value2
                    print type(value2)

                    if value1 >= 1 and value2 < 1:
                        return i

    def getDistance(self, age, pregnancyStatus, scoreI, moderatePerWeek,
                    vigorousPerWeek):
        dist = 0
        if scoreI == 1:
            dist = math.sqrt((moderatePerWeek*moderatePerWeek) +
                             (vigorousPerWeek*vigorousPerWeek))
        else:
            try:
                a = np.array([[1/self.getModerate(age, pregnancyStatus, scoreI),
                               1/self.getVigorous(age, pregnancyStatus, scoreI)],
                             [vigorousPerWeek, -1 * moderatePerWeek]])

                b = np.array([1, 0])
                # x = np.linalg.solve(a, b)
                x = np.linalg.lstsq(a, b)

                x1 = x[0]
                x2 = x[1]

                y = (moderatePerWeek - x1[0]) * (moderatePerWeek - x1[0])
                z = (vigorousPerWeek - x1[1]) * (vigorousPerWeek - x1[1])
                dist = math.sqrt(y + z)

            except np.linalg.linalg.LinAlgError as err:
                if 'Singular matrix' in err.message:
                    print "error"
                    print err
                else:
                    raise
        return dist

    def getAerobicScore(self, distI, scoreI, distII, scoreII):
        value = (distII*scoreI)/(distI+distII) + (distI*scoreII)/(distI+distII)
        return value

    def loadData(self, path_to_file):
        """ Returns dictionary object
        Based on path to json file, returns python dictionary
        """
        with open(path_to_file) as json_data:
            d = json.load(json_data)
        return d

    def getRawScore(self, aerobicScore, muscleScore):
        power = 1
        aerobicWeight = 0.55
        x = aerobicWeight * math.pow(aerobicScore, power)
        y = (1 - aerobicWeight) * math.pow(muscleScore, power)
        rawScore = math.pow(x+y, 1/power)

        return rawScore

    def getFinalScore(self, rawScore):
        mapping = {
            1: 30,
            1.1: 32,
            1.2: 34,
            1.3: 36,
            1.4: 38,
            1.5: 40,
            1.6: 42,
            1.7: 44,
            1.8: 46,
            1.9: 48,
            2: 50,
            2.1: 53,
            2.2: 56,
            2.3: 59,
            2.4: 62,
            2.5: 65,
            2.6: 68,
            2.7: 71,
            2.8: 74,
            2.9: 77,
            3: 80,
            3.1: 82,
            3.2: 84,
            3.3: 86,
            3.4: 88,
            3.5: 90,
            3.6: 92,
            3.7: 94,
            3.8: 96,
            3.9: 98,
            4: 100
        }

        return mapping[round(rawScore, 1)]

    def getMuscleScoreI(self, musclePerWeek):
        val = 1
        if musclePerWeek > 3:
            val = 4
        for i in range(1,4):
            if i <= musclePerWeek <= (i+1):
                val = i
        return val

    def getMuscleScore(self, musclePerWeek):
        sessions = {
          1: 0,
          2: 1,
          3: 2,
          4: 3
        }
        muscleScore = 1
        i = self.getMuscleScoreI(musclePerWeek)
        print "getMuscleScore:::"
        print "i:::"
        print i
        print "sessions[i+1]"
        print sessions[i+1]
        print "sessions[i]"
        print sessions[i]
        print "musclePerWeek::"
        print musclePerWeek
        if i == 4:
            muscleScore = 4
        else:
            muscleScore = (musclePerWeek - sessions[i])/(sessions[i+1] - sessions[i]) + i
            print "muscleScore::"
            print muscleScore
        return muscleScore


    def getScore(self, activityData, user):
        print "user pregnancy status: "
        t = datetime.now()
        d = self.day_of_week(t)
        #print user['pregnancy_status']
        pregnancyStatus = bool(user.pregnancy_status)
        dateOfBirth = datetime.strptime(str(user.date_of_birth), "%Y-%m-%d")
        joinDate = datetime.strptime(str(user.created), "%Y-%m-%d")
        raw_data = activityData
        df = pd.read_json(raw_data)
        df.columns = df.columns.map(lambda x: x.split(".")[-1])
        df["activity_segment"] = df['activity_category'].map(self.CATEGORY_MAP)
        print "date:"
        print df['start_time']
        df['start_date'] = df.apply(
            lambda x: pd.to_datetime(x['start_time']), axis=1)
        
        # evaluation date
        df["year"] = df['start_date'].dt.year
        df["month"] = df['start_date'].dt.month
        df['day'] = df['start_date'].dt.day

        evaluationDate = datetime.now()

        age = self.getAge(evaluationDate.month, dateOfBirth.month, evaluationDate.day, 
                          dateOfBirth.day, evaluationDate.year, dateOfBirth.year)
        earliestDate = self.getEarliestDate(joinDate, evaluationDate)
        print "earliest date:::"
        print earliestDate
        print "evaluation date:"
        print evaluationDate
        weeks = self.weeks(evaluationDate, earliestDate)
        print "data frame::"
        print df
        print "start_date df"
        print df['start_date']
        df2 = df

        df2 = df2[(df2['start_date'] > self.get_start_date(t, d)) &
                (df2['start_date'] < self.get_end_date(t, d))]


        df_moderate2 = df2[df2['activity_segment'] == 'Moderate']
        mod = df_moderate2['duration'].div(60*weeks).sum()

        df_vigorous2 = df2[df2['activity_segment'] == 'Vigorous']
        vig = df_vigorous2['duration'].div(60*weeks).sum()

        df_muscle2 = df2[df2['activity_segment'] == 'Muscle Strenghtening']
        mus = df_muscle2['duration'].div(60*weeks).sum()

        df = df[(df['start_date'] > earliestDate) &
                (df['start_date'] < evaluationDate)]


        df_moderate = df[df['activity_segment'] == 'Moderate']

        df_vigorous = df[df['activity_segment'] == 'Vigorous']
        df_muscle = df[df['activity_segment'] == 'Muscle Strenghtening']

        print "weeks:"
        print weeks

        print "moderatePerWeek:"
        print df_moderate
        print df_moderate['duration']
        print df_moderate['duration'].div(60*weeks)
        print df_moderate['duration'].div(60*weeks).sum()
        print df_moderate['duration'].div(60*weeks).sum()
        print df_moderate['duration']

        print "vigorousPerWeek:"
        print df_vigorous
        print df_vigorous['duration']
        print df_vigorous['duration'].div(60*weeks).sum()
        print df_vigorous['duration']

        moderatePerWeek = df_moderate['duration'].div(60*weeks).sum()
        vigorousPerWeek = df_vigorous['duration'].div(60*weeks).sum()
        musclePerWeek = df_muscle['duration'].div(1050*weeks).sum()

        print "moderatePerWeek"
        print moderatePerWeek
        print "vigorousPerWeek"
        print vigorousPerWeek
        scoreI = self.getScoreI(age, pregnancyStatus,
                                moderatePerWeek, vigorousPerWeek)

        scoreII = scoreI+1

        distI = self.getDistance(age, pregnancyStatus,
                                 scoreI, moderatePerWeek, vigorousPerWeek)

        if scoreI == 4:
            scoreII = 4
            scoreI = 3

        distII = self.getDistance(age, pregnancyStatus,
                                  scoreII, moderatePerWeek, vigorousPerWeek)
        aerobicScore = self.getAerobicScore(distI, scoreI, distII, scoreII)

        muscleScore = self.getMuscleScore(musclePerWeek)
        
        rawScore = self.getRawScore(aerobicScore, muscleScore)

        finalScore = self.getFinalScore(rawScore)
        moderate_aerobic = self.getModerate(age, pregnancyStatus, scoreI)
        vigorous_aerobic = self.getVigorous(age, pregnancyStatus, scoreI)
        muscle_strengthening = self.muscleStrengthening(age, pregnancyStatus, scoreI)

        finalScore_dict = {
            'moderate_aerobic': mod, 
            'vigorous_aerobic': vig,
            'muscle_strengthening': mus,
            'score': finalScore,
            'evaluation_date': evaluationDate,
            'week_start_date': self.get_start_date(t, d),
            'week_end_date': self.get_end_date(t, d)
        }

        return finalScore_dict

    def get_start_date(self, t, d):
        if d == 0:
            return t - timedelta(days=6)
        elif d == 1:
            return t
        return t - timedelta(days=d-1)

    def get_end_date(self, t, d):
        if d == 0:
            return t
        return t + timedelta(days=7-d)

    def day_of_week(self, current_date):
        d = current_date.day
	m = current_date.month
	y = current_date.year
        t = [0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4]
        y -= m < 3
        return ( y + y/4 - y/100 + y/400 + t[m-1] + d) % 7

    def healthScore(self, activityData, user):
	return self.getScore(activityData, user)
