
from kafka import KafkaConsumer, SimpleProducer, KafkaClient
import avro.schema
import avro.io
import io
import json
# To consume messages
consumer = KafkaConsumer('ActivityDataTopic',
                         bootstrap_servers=['10.246.65.82:9092'])

# To send messages synchronously
kafka = KafkaClient('10.246.65.82:9092')
producer = SimpleProducer(kafka)

# Kafka topic
topic = "HealthScoreTopic"

activity_schema_path="activity.avsc"
activity_schema = avro.schema.parse(open(activity_schema_path).read())

health_score_event_schema_path="healthScore.avsc"
health_score_event_schema = avro.schema.parse(open(health_score_event_schema_path).read())


for msg in consumer:
    bytes_reader = io.BytesIO(msg.value)
    decoder = avro.io.BinaryDecoder(bytes_reader)
    reader = avro.io.DatumReader(activity_schema)
    activity = reader.read(decoder)

    print json.dumps(activity, indent=4, sort_keys=True)
    print "compute some score"
    payload = {
        "eventId": "TestEventId",
        "eventType": "HealthScoreEvent",
        "optType": "Create",
        "external_user_id": "someID",
        "date_time": "2017-03-01",
        "score": "45",
        "moderate_aerobic": "285",
        "vigorous_aerobic": "60",
        "muscle_strengthening": "2"
        }

    writer = avro.io.DatumWriter(health_score_event_schema)
    bytes_writer = io.BytesIO()
    encoder = avro.io.BinaryEncoder(bytes_writer)
    writer.write(payload, encoder)
    raw_bytes = bytes_writer.getvalue()
    producer.send_messages(topic, raw_bytes)
# To consume messages
consumer = KafkaConsumer('ActivityDataTopic',
                         bootstrap_servers=['10.246.65.82:9092'])

# To send messages synchronously
health_score_event_schema = avro.schema.parse(open(health_score_event_schema_path).read())


for msg in consumer:
    bytes_reader = io.BytesIO(msg.value)
    decoder = avro.io.BinaryDecoder(bytes_reader)
    reader = avro.io.DatumReader(activity_schema)
    activity = reader.read(decoder)

    print json.dumps(activity, indent=4, sort_keys=True)
    print "compute some score"
    payload = {
        "eventId": "TestEventId",
        "eventType": "HealthScoreEvent",
        "optType": "Create",
        "external_user_id": "someID",
        "date_time": "2017-03-01",
        "score": "45",
        "moderate_aerobic": "285",
        "vigorous_aerobic": "60",
        "muscle_strengthening": "2"
        }

    writer = avro.io.DatumWriter(health_score_event_schema)
    bytes_writer = io.BytesIO()
    encoder = avro.io.BinaryEncoder(bytes_writer)
    writer.write(payload, encoder)
    raw_bytes = bytes_writer.getvalue()
    producer.send_messages(topic, raw_bytes)
