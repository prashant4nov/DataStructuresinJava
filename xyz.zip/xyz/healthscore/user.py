#!/usr/bin/env python
import json
import logging
import datetime
import pandas as pd
import numpy as np
import math
import datetime
import json as simplejson
from cassandra import ConsistencyLevel
from cassandra.cluster import Cluster
from cassandra.query import SimpleStatement

'''
    File name: user.py
    Author: Prashant Kumar
    Date created: 9/22/2017
    Python Version: 2.7
'''

class User(object):

    def __init__(self, id):
        self.id = id        
        # cassandra settings
        cluster = Cluster(['127.0.0.1'])
        self.session = cluster.connect()
        self.session.set_keyspace("payl")

    def getActivityData(self):
        query = "SELECT * FROM activity WHERE external_id='%s' ALLOW FILTERING"
        rows = self.session.execute(query % self.id)
        activities_dict = []
        for r in rows:
            activity = {
              'activity_id':r.activity_id,
              'activity_category':r.activity_category,
              'activity_type':r.activity_type,
              'calories':r.calories,
              'created':r.created,
              'distance':r.distance,
              'duration':r.duration,
              'external_id':r.external_id,
              'intensity':r.intensity,
              'source':r.source,
              'start_time':r.start_time,
              'steps':r.steps,
              'updated':r.updated,
              'utc_offset':r.utc_offset  
            }
            activities_dict.append(activity)

        return simplejson.dumps(activities_dict)

    def getUser(self):
        query = "SELECT * FROM user WHERE external_user_id='%s' ALLOW FILTERING"
        row = self.session.execute(query % self.id)
        print row[0].pregnancy_status
        print row[0].date_of_birth
        print "user info>>>>>>>>>"
        return row[0]

    def saveActivity(self, activity):
        prepared = self.session.prepare("""
            insert into activity (activity_id, activity_category, 
            activity_type, calories, created, distance, duration, 
            external_id, intensity, source, start_time,
            updated) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""")

        # save data to cassandra activity table
        self.session.execute(prepared, (
            activity["activity_id"],
            activity["activity_category"],
            activity["activity_type"],
            int(activity["calories"]),
            activity["created"],
            float(activity["distance"]),
            int(activity["duration"]),
            activity["external_id"],
            activity["intensity"],
            activity["source"],
            activity["start_time"],
            activity["updated"]))
