
from kafka import SimpleProducer, KafkaClient
import avro.schema
import io, random
from avro.io import DatumWriter

# To send messages synchronously
kafka = KafkaClient('10.246.65.82:9092')
producer = SimpleProducer(kafka)

# Kafka topic
topic = "ActivityDataTopic"

# Path to user.avsc avro schema
schema_path="activity.avsc"
schema = avro.schema.parse(open(schema_path).read())

payload = {
    "eventId": "TestEventId",
    "eventType": "Activity",
    "optType": "Create",
    "activity_id": "229be39c-65dd-49d4-9df3-2ae3c92b1711",
    "external_id": "123",
    "activity_type": "running",
    "activity_category": "running",
    "duration": "3600",
    "start_time": "2017-03-16T02:00:00Z",
    "intensity": "moderate",
    "distance": "6241",
    "calories": "2310",
    "source": "fitbit",
    "created": "2017-03-16T02:00:00Z",
    "updated": "2017-03-16T02:00:00Z ",
    "utc_offset": "2017-03-14T01:00:00Z"
    }

writer = avro.io.DatumWriter(schema)
bytes_writer = io.BytesIO()
encoder = avro.io.BinaryEncoder(bytes_writer)
writer.write(payload, encoder)
raw_bytes = bytes_writer.getvalue()
producer.send_messages(topic, raw_bytes)
