#!/usr/bin/env python
from kafka import KafkaConsumer, SimpleProducer, KafkaClient
import avro.schema
import avro.io
import json as simplejson
import io
import datetime
import json
from user import User
from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from cassandra import ConsistencyLevel
from cassandra.cluster import Cluster
from cassandra.query import SimpleStatement
from health_score import HealthScore
import schedule
import time


# Create a StreamingContext with batch interval of 3 second
sc = SparkContext("local[2]", "scoreWeekly")
ssc = StreamingContext(sc, 1)

# cassandra settings
cluster = Cluster(['10.246.65.71'])
session = cluster.connect()
session.set_keyspace("payl")
hs = HealthScore()

def getActivityData(user_id):
    user = User(user_id)
    return user.getActivityData()


def getUser(external_id):
    user = User(external_id)
    return user.getUser()

def saveScore():
    pass

def getHealthScore(user):
    activityData = getActivityData(user.external_user_id)
    return hs.healthScore(activityData, user)

def getUsers():
    query = "SELECT * FROM user;"
    row = session.execute(query)
    return row

def main():
    # To consume messages
    #consumer = KafkaConsumer('ActivityDataTopic',
    #                         bootstrap_servers=['localhost:9092'])

    # To send messages synchronously
    kafka = KafkaClient('localhost:9092')
    producer = SimpleProducer(kafka)

    # Kafka topic
    topic = "HealthScoreTopic"

    #activity_schema_path="activity.avsc"
    #activity_schema = avro.schema.parse(open(activity_schema_path).read())

    health_score_event_schema_path="healthScore.avsc"
    health_score_event_schema = avro.schema.parse(open(health_score_event_schema_path).read())

    users = getUsers()

    for u in users:
        score_dictionary = getHealthScore(u)
        print score_dictionary

        payload = {
            "eventId": "TestEventId",
            "eventType": "HealthScoreEvent",
            "optType": "Create",
            "external_user_id": str(u.external_user_id),
            "date_time": str(datetime.datetime.now()),
            "score": str(score_dictionary['score']),
            "moderate_aerobic": str(score_dictionary['moderate_aerobic']),
            "vigorous_aerobic": str(score_dictionary['vigorous_aerobic']),
            "muscle_strengthening": str(score_dictionary['muscle_strengthening']),
            "score_type": "weekly"
            }

        writer = avro.io.DatumWriter(health_score_event_schema)
        bytes_writer = io.BytesIO()
        encoder = avro.io.BinaryEncoder(bytes_writer)
        writer.write(payload, encoder)
        raw_bytes = bytes_writer.getvalue()
        producer.send_messages(topic, raw_bytes)

if __name__ ==  "__main__":
    #schedule.every().sunday.at("23:59").do(main())
    #schedule.every(1).seconds.do(main)
    ssc.start()             # Start the computation
    main()
    ssc.awaitTermination()  # Wait for the computation to terminate
