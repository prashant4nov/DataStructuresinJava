from kafka import KafkaConsumer, SimpleProducer, KafkaClient
import avro.schema
import avro.io
import json as simplejson
import io
import datetime
import json
from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from cassandra import ConsistencyLevel
from cassandra.cluster import Cluster
from cassandra.query import SimpleStatement
from health_score import HealthScore


# Create a StreamingContext with batch interval of 3 second
sc = SparkContext("local[2]", "myAppName")
ssc = StreamingContext(sc, 1)

# cassandra settings
#cluster = Cluster(['127.0.0.1'])
cluster = Cluster(['10.246.65.71'])
session = cluster.connect()
session.set_keyspace("payl")


def getActivityData(user_id):
    rows = session.execute("SELECT * FROM activity where external_id='%s' allow filtering;" % user_id)
    activities_dict = []
    for r in rows:
        activity = {
          'activity_id':r.activity_id,
          'activity_category':r.activity_category,
          'activity_type':r.activity_type,
          'calories':r.calories,
          'created':r.created,
          'distance':r.distance,
          'duration':r.duration,
          'external_id':r.external_id,
          'intensity':r.intensity,
          'source':r.source,
          'start_time':r.start_time,
          'steps':r.steps,
          'updated':r.updated,
          'utc_offset':r.utc_offset  
        }
        activities_dict.append(activity)

    return simplejson.dumps(activities_dict)


def getUser(external_id):
    print "external id "
    print external_id
    query = "SELECT * FROM user WHERE external_id='%s' ALLOW FILTERING"
    row = session.execute(query % external_id)
    print row[0]
    print row[0].pregnancy_status
    print "user info>>>>>>>>>"
    return row[0]

def saveScore():
    pass

def getHealthScore(user_id):
    user = getUser(user_id)
    activityData = getActivityData(user_id)
    hs = HealthScore()
    return hs.healthScore(activityData, user)


def main():
    # To consume messages
    consumer = KafkaConsumer('ActivityDataTopic',
                             bootstrap_servers=['10.246.65.82:9092'])

    # To send messages synchronously
    kafka = KafkaClient('10.246.65.82:9092')
    producer = SimpleProducer(kafka)

    # Kafka topic
    topic = "HealthScoreTopic"

    activity_schema_path="activity.avsc"
    activity_schema = avro.schema.parse(open(activity_schema_path).read())

    health_score_event_schema_path="healthScore.avsc"
    health_score_event_schema = avro.schema.parse(open(health_score_event_schema_path).read())

    for msg in consumer:
        bytes_reader = io.BytesIO(msg.value)
        decoder = avro.io.BinaryDecoder(bytes_reader)
        reader = avro.io.DatumReader(activity_schema)
        activity = reader.read(decoder)

        prepared = session.prepare("""
            insert into activity (activity_id, activity_category, 
            activity_type, calories, created, distance, duration, 
            external_id, intensity, source, start_time, steps,
            utc_offset, updated) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""")

        # save data to cassandra activity table
        session.execute(prepared, (
            activity["activity_id"],
            activity["activity_category"],
            activity["activity_type"],
            int(activity["calories"]),
            activity["created"],
            float(activity["distance"]),
            int(activity["duration"]),
            activity["external_id"],
            activity["intensity"],
            activity["source"],
            activity["start_time"],
            100,
            "2017-03-01",
            activity["updated"]))

        score_dictionary = getHealthScore(activity["external_id"])

        print json.dumps(activity, indent=4, sort_keys=True)
        print "computed  score>>>>>>>>>>>"
        #print score_dictionary
        evaluationDate = datetime.datetime.strptime(
            '26072017', "%d%m%Y").date()
        print "updated date: %s" % str(activity["updated"]) 
        payload = {
            "eventId": "TestEventId",
            "eventType": "HealthScoreEvent",
            "optType": "Create",
            "external_user_id": str(activity["external_id"]),
            "score": str(score_dictionary['score']),
            "moderate_aerobic": str(score_dictionary['moderate_aerobic']),
            "vigorous_aerobic": str(score_dictionary['vigorous_aerobic']),
            "muscle_strengthening": str(score_dictionary['muscle_strengthening']),
            "week_start_date": str(score_dictionary['week_start_date']),
            "week_end_date": str(score_dictionary['week_end_date'])
            }

        writer = avro.io.DatumWriter(health_score_event_schema)
        bytes_writer = io.BytesIO()
        encoder = avro.io.BinaryEncoder(bytes_writer)
        writer.write(payload, encoder)
        raw_bytes = bytes_writer.getvalue()
        try:
           producer.send_messages(topic, raw_bytes)
        except:
           producer.send_messages(topic, raw_bytes)

if __name__ ==  "__main__":
    main()
    ssc.start()             # Start the computation
    ssc.awaitTermination()  # Wait for the computation to terminate
