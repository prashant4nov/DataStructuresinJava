/**
 * 
 */
package mockRabbitProducer;

/**
 * @author kadamab
 *
 */

import java.util.concurrent.CountDownLatch;
import org.springframework.stereotype.Component;

@Component
public class Receiver {

}
