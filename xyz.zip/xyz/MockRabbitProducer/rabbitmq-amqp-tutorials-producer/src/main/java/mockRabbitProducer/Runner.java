package mockRabbitProducer;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class Runner implements CommandLineRunner {

	private final RabbitTemplate rabbitTemplate;
	//private final Receiver receiver;
	private final ConfigurableApplicationContext context;
	
	@Value("${queue.name}")
    public String queueName;

	public Runner(RabbitTemplate rabbitTemplate, ConfigurableApplicationContext context) {
		this.rabbitTemplate = rabbitTemplate;
		this.context = context;
	}

    //@Override
    public void run(String... args) throws Exception {
        System.out.println("Sending message...");
        System.out.println("Queue Name :::: "+queueName);
        
        Object message = null;
        
        for(int i=0;i<1;i++) {
        
        if(queueName.equals("ey_userfeed")) {
    	
        	message = new String("{ "
            		+ "\"id\": \"1101\","
             		+ "\"external_user_id\": \"12345\","
             		+ " \"health_id\":\"11\","
             		+ "\"first_name\": \"John\","
             		+ "\"last_name\": \"Doe\" ,"
             		+ "\"email\": \"john.doe@gmail.com\" ,"
             		+ "\"driver_license\": \"CFOKJ123\" ,"
             		+ "\"gender\": \"Male\" ,"
             		+ "\"status\": \"Active\" ,"
             		+ "\"application_type\": \"Normal\" ,"
             		+ "\"display_name\": \"John\" ,"
             		+ "\"mobile_phone\": \"1111111111\" ,"
             		+ "\"office_phone\": \"1111111111\" ,"
             		+ "\"home_phone\": \"1111111111\" ,"
             		+ "\"date_of_birth\": \" 01/10/1960\" ,"
             		+ "\"language\": \" English\" ,"
             		+ "\"promotional_email\": \"john.doe@gmail.com \" ,"
             		
             		//address
             		+ "\"address\": {"
             		+ "\"id\": \"e9739366-76dd-4c84-ba45-9a46966ca5cc\" ,"
             		+ "\"street_number\": \" 101\" ,"
             		+ "\"street_name\": \" Santa Clara\" ,"
             		+ "\"city\": \" San Jose\" ,"
             		+ "\"country\": \"United States\" ,"
             		+ "\"state\": \" CA\" ,"
             		+ "\"zip_code\": \"95112\" ,"
             		+ "\"appartment\": \"4220\" "
             		+  "},"
             		//address ends 
             		
             		// health object
             		+ "\"health\": {"
             		+ "\"weight\": \" 160\" ,"
             		+ "\"body_type\": \"Muscular\" ,"
             		+ "\"pregnancy_status\": \"NA \" ,"
             		+ "\"pregnancy_details\": \" NA\" ,"
             		+ "\"disability_status\": \"NA \" ,"
             		+ "\"disability_details\": \" NA\" "
             		+  "},"
             		//health object ends
             		
             		+ "\"created\": \" 08/07/2017\" ,"
             		+ "\"updated\": \" 08/07/2017\" "  		
             		+ "}" );
        	
        		}
        
       
        	 if(queueName.equals("payl_data")){
        		 message = new String("{ "
                 		+ "\"activity_id\": \"229be39c-65dd-49d4-9df3-2ae3c92b1711\","
                  		+ "\"external_id\": \"a49251b8-75e5-45fc-a08b-2aa089c0ffaa\","
                  		+ " \"activity_type\":\"Running\","
                  		+ "\"activity_category\": \"Running\","
                  		+ "\"duration\": \"7200\" ,"
                  		+ "\"start_time\": \"2017-03-16T02:00:00Z\" ,"
                  		+ "\"intensity\": null ,"
                  		+ "\"distance\": \"6241\" ,"
                  		+ "\"calories\": \"2310\" ,"
                  		+ "\"source\": \" Fitbit\" ,"
                  		+ "\"created\": \" 2017-03-16T02:00:00Z\" ,"
                  		+ "\"updated\": \"2017-03-16T02:00:00Z \" ,"
                  		+ "\"utc_offset\": \"+08:00 \" "
                  		+ "}" );	 
        	 }
        	 
        	 if(queueName.equals("reward-redeem")){
        		 message = new String("{ "
                  		+ "\"external_user_id\": \"37311ba1-561f-4e7d-8059-7b1f62b2744c\","
                  		+ " \"date_time\":\"2017-03-16T02:00:00Z\","
                  		+ "\"reward_id\": \"a1b48161-aeda-4b1a-880c-71abb6fd0744\","
                  		+ "\"coins_deducted\": \"230\" ,"
                  		+ "\"balance\": \"5000\" "
                  		+ "}" );	 
        	 }
        	 
        	 if(queueName.equals("coins_activity")){
        		 message = new String("{ "
                  		+ "\"external_user_id\": \"37311ba1-561f-4e7d-8059-7b1f62b2744c\","
                  		+ " \"date_time\":\"2017-03-16T02:00:00Z\","
                  		+ "\"score\": \"76\","
                  		+ "\"moderate_aerobic\": \"2541\" ,"
                  		+ "\"vigourous_aerobic\": \"684\", "
                  		+ "\"muscle_strengthening\": \"951\" "
                  		+ "}" );	 
        	 }
        	 
        	 if(queueName.equals("payl_scores")){
        		 message = new String("{ "
                  		+ "\"external_user_id\": \"599b2188-c67c-4c9a-be45-1f88c0a87a11\","
                  		+ " \"week_start_date\":\"2017-09-11T00:00:01Z\","
                  		+ " \"week_end_date\":\"2017-09-17T23:59:59Z\","
                  		+ "\"score\": \"65\","
                  		+ "\"moderate_aerobic\": \"2541\" ,"
                  		+ "\"vigourous_aerobic\": \"684\", "
                  		+ "\"muscle_strengthening\": \"951\" "
                  		+ "}" );	 
        	 }
        	 
        	 if(queueName.equals("ey_coins_deposit")){
        		 message = new String("{ "
        				+ "\"id\": \"37311ba1-561f-4e7d-8059-7b1f62b2744c\","
                   		+ "\"external_user_id\": \"37311ba1-561f-4e7d-8059-7b1f62b2744c\","
                   		+ " \"date_time\":\"2017-03-16T02:00:00Z\","
                   		+ "\"deposit_description\": \"This is a coin deposit for answering profile related questions\","
                   		+ "\"amount\": \"230\" ,"
                   		+ "\"balance\": \"5000\" "
                   		+ "}" );	 
        	 }
        
        
		rabbitTemplate.convertAndSend(this.queueName, message, new MessagePostProcessor() {
			// @Override
			public Message postProcessMessage(Message m) throws AmqpException {
				
				if(queueName.equalsIgnoreCase("ey_userfeed")) {
					m.getMessageProperties().getHeaders().put("message-type", "user.created");
				}
				if(queueName.equalsIgnoreCase("payl_data")) {
					m.getMessageProperties().getHeaders().put("message-type", "activity");
				}
				if(queueName.equalsIgnoreCase("reward-redeem")) {
					m.getMessageProperties().getHeaders().put("message-type", "reward_redeem");
				}
				if(queueName.equalsIgnoreCase("coins_activity")) {
					m.getMessageProperties().getHeaders().put("message-type", "score.daily");
				}
				if(queueName.equalsIgnoreCase("payl_scores")) {
					m.getMessageProperties().getHeaders().put("message-type", "score.weekly");
				}
				if(queueName.equalsIgnoreCase("ey_coins_deposit")) {
					m.getMessageProperties().getHeaders().put("message-type", "coins_deposit");
				}
				m.getMessageProperties().getHeaders().put("Content-Type", "application/json");
				m.getMessageProperties().getHeaders().put("Version", "1");
				return m;
			}
		});
		
        }
		context.close();
	}
}



