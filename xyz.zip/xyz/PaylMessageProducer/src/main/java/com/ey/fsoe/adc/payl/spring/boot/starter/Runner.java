package com.ey.fsoe.adc.payl.spring.boot.starter;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

import com.ey.fsoe.adc.payl.kafka.Receiver;

@Component
public class Runner implements CommandLineRunner {
	
	  @Autowired
	  private Receiver receiver;
	  
	  @Value("${queue.name}")
	  private String queueName;

	  public final RabbitTemplate rabbitTemplate;
	  private final ConfigurableApplicationContext context;

	public Runner( Receiver receiver, RabbitTemplate rabbitTemplate, ConfigurableApplicationContext context) {
		this.receiver = receiver;
		this.rabbitTemplate = rabbitTemplate;
		this.context = context;  
	}

    public void run(String... args) throws Exception {
    	
    	receiver.getLatch().await();
	}

}

