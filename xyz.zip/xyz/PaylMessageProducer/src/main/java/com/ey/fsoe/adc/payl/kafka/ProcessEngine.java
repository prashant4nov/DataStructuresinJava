package com.ey.fsoe.adc.payl.kafka;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.apache.avro.specific.SpecificRecordBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import example.avro.HealthScoreEvent;
import example.avro.RewardRedemptionAcknowledgmentEvent;
import example.avro.CoinDepositAcknowledgmentEvent;

/**
 * @author kadamab
 *
 */

public class ProcessEngine {

	@Autowired
	private RabbitTemplate rabbitTemplate;

	@Value("${queue.name}")
	private String queueName;

	private static final Logger LOGGER = LoggerFactory.getLogger(Receiver.class);

	public void processEvent(SpecificRecordBase event) {
		LOGGER.info("processEvent() method for " + event.get("eventType").toString() +"Event");

		if (event.get("eventType").toString().equalsIgnoreCase("HealthScoreEvent")) {
			HealthScoreEvent healthScoreEvent = (HealthScoreEvent) event;
			Object message = this.createPayload(healthScoreEvent);
			MessagePostProcessor mpp = this.addHeader("score.weekly");
			this.rabbitTemplate.convertAndSend(this.queueName, message, mpp);
			LOGGER.info("Sent HealthScoreMessage='{}'", message);
		}

		if (event.get("eventType").toString().equalsIgnoreCase("RewardRedemptionAcknowledgment")) {
			RewardRedemptionAcknowledgmentEvent rewardAck = (RewardRedemptionAcknowledgmentEvent) event;
			Object message = this.createPayload(rewardAck);
			MessagePostProcessor mpp = this.addHeader("reward-redemption.ack");
			this.rabbitTemplate.convertAndSend(this.queueName, message, mpp);
			LOGGER.info("Sent Reward Redemption Acknowledgment Message='{}'", message);
		}
		
		if (event.get("eventType").toString().equalsIgnoreCase("CoinsDeposit")) {
			CoinDepositAcknowledgmentEvent coinDepositAck = (CoinDepositAcknowledgmentEvent) event;
			Object message = this.createPayload(coinDepositAck);
			MessagePostProcessor mpp = this.addHeader("coins_deposit");
			this.rabbitTemplate.convertAndSend(this.queueName, message, mpp);
			LOGGER.info("Sent Coin Deposit Message='{}'", message);
		}
	}

	public Object createPayload(HealthScoreEvent healthScoreEvent) {
		Object payload = new String(
				"{ " + "\"external_user_id\":\"" + healthScoreEvent.getExternalUserId() + "\"," + "\"week_end_date\":\""
						+ healthScoreEvent.getWeekEndDate() + "\"," + "\"score\":\"" + healthScoreEvent.getScore() + "\","
						+ "\"moderate_aerobic\":\"" + healthScoreEvent.getModerateAerobic() + "\","
						+ "\"vigorous_aerobic\":\"" + healthScoreEvent.getVigorousAerobic() + "\","
						+ "\"muscle_strengthening\":\"" + healthScoreEvent.getMuscleStrengthening() + "\","
						+ "\"week_start_date\":\"" + healthScoreEvent.getWeekStartDate() + "\"" + "}");
		
		return payload;
	}

	private Object createPayload(RewardRedemptionAcknowledgmentEvent ackEvent) {
		Object payload = new String(
				"{ " + "\"external_user_id\":\"" + ackEvent.getExternalUserId() + "\"," 
					 + "\"reward_id\":\"" + ackEvent.getRewardId() + "\"," 
					 + " \"balance\":\"" + ackEvent.getBalance() + "\" " 
				+ "}");
		
		return payload;
	}

	private Object createPayload(CoinDepositAcknowledgmentEvent event) {
		Object payload = new String(
				"{ " 
						+ "\"id\":\"" + event.getId() + "\","
						+ "\"external_user_id\":\"" + event.getExternalUserId() + "\"," 
						+ "\"date_time\":\"" + event.getDateTime() + "\"," 
						+ "\"deposit_description\":\"" + event.getDepositDescription() + "\" ,"
						+ "\"amount\":\"" + event.getAmount() + "\"," 
						+ "\"balance\":\"" + event.getBalance() + "\" " 
				+ "}");
		
		return payload;
	}
	
	public MessagePostProcessor addHeader(String messageType) {
		MessagePostProcessor mpp = (Message m) -> {
			m.getMessageProperties().getHeaders().put("Message-Type", messageType);
			m.getMessageProperties().getHeaders().put("Content-Type", "application/json");
			m.getMessageProperties().getHeaders().put("Version", "1");
			return m;
		};
		return mpp;
	}
}
