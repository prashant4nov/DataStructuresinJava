package com.ey.fsoe.adc.payl.kafka;

import static org.junit.Assert.assertTrue;

/**
 * @author kadamab
 *
 */
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Unit test for simple App.
 */

public class ReceiverTest {//extends TestCase {
	protected Logger logger = LoggerFactory.getLogger(this.getClass());
	@Rule public TestName name = new TestName();
	
	@Before
	public void setup(){
		logger.info("\n*** Starting Test {} ***", name.getMethodName());
	}
	
	@After
	public void teardown(){
		logger.info("*** Finished Test {} ***\n", name.getMethodName());
	}
	/**
     * Create the test case
     *
     * @param testName name of the test case
     */
//    public ReceiverTest( String testName )
//    {
//        super( testName );
//    }
    
    public void test_createPayload(){
    	
    }

    /**
     * @return the suite of tests being tested
     
    public static Test suite()
    {
        return new TestSuite( ReceiverTest.class );
    }*/

    /**
     * Rigourous Test :-)
     
    public void testApp()
    {
        assertTrue( true );
    }*/
}
