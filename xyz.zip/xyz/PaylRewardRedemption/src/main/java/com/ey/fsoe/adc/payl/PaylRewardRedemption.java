package com.ey.fsoe.adc.payl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Properties;
import java.util.UUID;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.Statement;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Update.Where;
import com.google.common.io.CharStreams;
import com.twitter.bijection.Injection;
import com.twitter.bijection.avro.GenericAvroCodecs;

public class PaylRewardRedemption {
	
	public static final String REWARD_REDEMPTION_SCHEMA = "{   \"namespace\": \"example.avro\",\n" + 
			"    \"type\":\"record\", \n" + 
			"    \"name\":\"RewardRedemptionEvent\",\n" + 
			"    \"fields\": [\n" + 
			"                 { \"name\":\"eventId\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"eventType\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"optType\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"external_user_id\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"date_time\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"reward_id\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"coins_deducted\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"balance\", \"type\":\"string\" }                    \n" + 
			"            ]\n" + 
			"}";
	public static final String REWARD_ACKNOWLEDGEMENT_SCHEMA = "{   \"namespace\": \"example.avro\",\n" + 
			"    \"type\":\"record\", \n" + 
			"    \"name\":\"RewardRedemptionAcknowledgmentEvent\",\n" + 
			"    \"fields\": [\n" + 
			"                { \"name\":\"eventId\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"eventType\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"optType\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"external_user_id\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"reward_id\", \"type\":\"string\" },                                \n" + 
			"                { \"name\":\"balance\", \"type\":\"string\" }                    \n" + 
			"            ]\n" + 
			"}";
	public static final String COINS_DEPOSIT_SCHEMA = "{   \"namespace\": \"example.avro\",\n" + 
			"    \"type\":\"record\", \n" + 
			"    \"name\":\"CoinDepositEvent\",\n" + 
			"    \"fields\": [\n" + 
			"                { \"name\":\"eventId\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"eventType\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"optType\", \"type\":\"string\" },\n" + 
			"                { \"name\": \"id\", \"type\":\"string\"},\n" + 
			"                { \"name\":\"external_user_id\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"date_time\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"deposit_description\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"amount\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"balance\", \"type\":\"string\" }                    \n" + 
			"            ]\n" + 
			"} ";
	public static final String COINS_ACKNOWLEDGEMENT_SCHEMA = "{   \"namespace\": \"example.avro\",\n" + 
			"    \"type\":\"record\", \n" + 
			"    \"name\":\"CoinDepositAcknowldgementEvent\",\n" + 
			"    \"fields\": [\n" + 
			"                { \"name\":\"eventId\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"eventType\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"optType\", \"type\":\"string\" },\n" + 
			"                { \"name\": \"id\", \"type\":\"string\"},\n" + 
			"                { \"name\":\"external_user_id\", \"type\":\"string\" },\n" + 
			"                { \"name\":\"date_time\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"deposit_description\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"amount\", \"type\":\"string\" },                \n" + 
			"                { \"name\":\"balance\", \"type\":\"string\" }                    \n" + 
			"            ]\n" + 
			"}";
	public static void main(String[] args) {
		Properties appProp = new Properties();
		InputStream appInput = null;
		Schema consumerSchema = null;
		Schema producerSchema = null;
		Cluster cluster = null;
		Session session = null;
		
		try {
			appInput = PaylRewardRedemption.class.getClassLoader().getResourceAsStream("application.properties");
			appProp.load(appInput);
			Schema.Parser parser = new Schema.Parser();
			if(appProp.getProperty("app.type").equals("RewardRedeem")) {
				consumerSchema = parser.parse(REWARD_REDEMPTION_SCHEMA);
				producerSchema = parser.parse(REWARD_ACKNOWLEDGEMENT_SCHEMA);
			}
			else if(appProp.getProperty("app.type").equals("CoinsDeposit")) {
				consumerSchema = parser.parse(COINS_DEPOSIT_SCHEMA);
				producerSchema = parser.parse(COINS_ACKNOWLEDGEMENT_SCHEMA);
			}
			cluster = Cluster.builder().addContactPoint(appProp.getProperty("cassandra.server")).build();
			session = cluster.connect(appProp.getProperty("cassandra.db"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		Injection<GenericRecord, byte[]> consumerRecordInjection;
		Injection<GenericRecord, byte[]> producerRecordInjection;
		
		consumerRecordInjection = GenericAvroCodecs.toBinary(consumerSchema);
		producerRecordInjection = GenericAvroCodecs.toBinary(producerSchema);

		Properties consumerProps = new Properties();
		consumerProps.put("bootstrap.servers", "localhost:9092");
		consumerProps.put("group.id", "test");
		consumerProps.put("enable.auto.commit", "true");
		consumerProps.put("auto.commit.interval.ms", "1000");
		consumerProps.put("session.timeout.ms", "30000");
		consumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		consumerProps.put("value.deserializer", "org.apache.kafka.common.serialization.ByteArrayDeserializer");

		KafkaConsumer<String, byte[]> consumer = new KafkaConsumer<String, byte[]>(consumerProps);
		System.out.println("Consumer Topic: " + appProp.getProperty("consumer.topic"));
		consumer.subscribe(Arrays.asList(appProp.getProperty("consumer.topic")));

		UUID reward_id = UUID.randomUUID();
		String oldEventId = "";
		String eventId = "";
		String eventType = "";
		String optType = "";
		String id = "";
		String external_user_id = "";
		String date_time = "";
		String deposit_description = "";
		Integer coins = 0;
		Integer balance = 0;

		while (true) {
			ConsumerRecords<String, byte[]> avroRecords = consumer.poll(100);
			for (ConsumerRecord<String, byte[]> avroRecord : avroRecords) {
				GenericRecord consumerRecord = consumerRecordInjection.invert(avroRecord.value()).get();
				if(appProp.getProperty("app.type").equals("RewardRedeem")) {
					reward_id = UUID.fromString(consumerRecord.get("reward_id").toString());
					eventId = consumerRecord.get("eventId").toString();
					eventType = consumerRecord.get("eventType").toString();
					optType = consumerRecord.get("optType").toString();
					external_user_id = consumerRecord.get("external_user_id").toString();
					coins = Integer.valueOf(consumerRecord.get("coins_deducted").toString());
				}
				else if(appProp.getProperty("app.type").equals("CoinsDeposit")) {
					eventId = consumerRecord.get("eventId").toString();
					eventType = consumerRecord.get("eventType").toString();
					optType = consumerRecord.get("optType").toString();
					id = consumerRecord.get("id").toString();
					external_user_id = consumerRecord.get("external_user_id").toString();
					date_time = consumerRecord.get("date_time").toString();
					deposit_description = consumerRecord.get("deposit_description").toString();
					coins = Integer.valueOf(consumerRecord.get("amount").toString());
					System.out.println("Received eventId: " + eventId + " eventType: " + eventType
							+ " optType: " + optType + " id: " + id + " external_user_id: " + external_user_id
							+ " date_time: " + date_time + " deposit_description: " + deposit_description
							+ " amount: " + coins.toString());
				}
				if (eventId != oldEventId) {
					oldEventId = eventId;
				
					if(appProp.getProperty("app.type").equals("RewardRedeem")) {
					Where update = QueryBuilder.update
							(appProp.getProperty("cassandra.db"), appProp.getProperty("cassandra.table.reward"))
							.with(QueryBuilder.set("is_valid", false))
							.where(QueryBuilder.eq("reward_uid", reward_id));
					session.execute(update.toString());
					}
					
					Statement select = QueryBuilder.select().all()
							.from(appProp.getProperty("cassandra.db"), appProp.getProperty("cassandra.table.user"))
							.where(QueryBuilder.eq("id", external_user_id)).limit(1);
					ResultSet results = session.execute(select.toString());
					
					for (Row r : results.all()) {
						balance = Integer.valueOf(r.getString("coins"));
						if(appProp.getProperty("app.type").equals("RewardRedeem")) {
						balance = balance - coins;
						}
						else if(appProp.getProperty("app.type").equals("CoinsDeposit")) {
							balance = balance + coins;
						}
					}

					Where update = QueryBuilder.update
							(appProp.getProperty("cassandra.db"), appProp.getProperty("cassandra.table.user"))
							.with(QueryBuilder.set("coins", balance.toString()))
							.where(QueryBuilder.eq("id", external_user_id));
					session.execute(update.toString());
				}

				Properties producerProps = new Properties();
				producerProps.put("bootstrap.servers", "localhost:9092");
				producerProps.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
				producerProps.put("value.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer");

				KafkaProducer<String, byte[]> producer = new KafkaProducer<String, byte[]>(producerProps);
				GenericData.Record producerRecord = new GenericData.Record(producerSchema);
				
				if(appProp.getProperty("app.type").equals("RewardRedeem")) {
					producerRecord.put("eventId", eventId);
					producerRecord.put("eventType", eventType);
					producerRecord.put("optType", optType);
					producerRecord.put("external_user_id", external_user_id);
					producerRecord.put("reward_id", reward_id.toString());
					producerRecord.put("balance", balance.toString());
				}
				else if(appProp.getProperty("app.type").equals("CoinsDeposit")) {
					producerRecord.put("eventId", eventId);
					producerRecord.put("eventType", eventType);
					producerRecord.put("optType", optType);
					producerRecord.put("id", id);
					producerRecord.put("external_user_id", external_user_id);
					producerRecord.put("date_time", date_time);
					producerRecord.put("deposit_description", deposit_description);
					producerRecord.put("amount", coins.toString());
					producerRecord.put("balance", balance.toString());
					System.out.println("Sending eventId: " + eventId + " eventType: " + eventType
							+ " optType: " + optType + " id: " + id + " external_user_id: " + external_user_id
							+ " date_time: " + date_time + " deposit_description: " + deposit_description
							+ " amount: " + coins.toString() + " balance: " + balance.toString());
				}

				byte[] bytes = producerRecordInjection.apply(producerRecord);

				ProducerRecord<String, byte[]> acknowledgementRecord = new ProducerRecord<String, byte[]>(
						appProp.getProperty("producer.topic"), bytes);
				producer.send(acknowledgementRecord);
				producer.close();
			}

		}

	}

}
