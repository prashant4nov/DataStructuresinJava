package com.ey.fsoe.adc.payl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.QueryBuilder;

public class RewardInventory {

	public static void main(String[] args) {
		Cluster cluster = Cluster.builder().addContactPoint("127.0.0.1").build();
	  	Session session = cluster.connect("payl");
	  	
	  	BufferedReader br = null;
//	  	BufferedWriter bw = null;
//		FileWriter fw = null;
	  	
	  	try {
	  		br = new BufferedReader(new FileReader("/Users/rh656zc/Documents/DOC/PAYL/rewards_out.csv"));
//	  		fw = new FileWriter("/Users/rh656zc/Documents/DOC/PAYL/rewards_out.csv");
//			bw = new BufferedWriter(fw);
	  		String line = br.readLine(); 
	  		//First line was header so read next line
	  		if(line != null) { 
//	  			bw.write(line);
//	  			bw.newLine();
	  			line = br.readLine();
	  		}
	  		while (line != null) {
  				//bw.write(UUID.randomUUID().toString() + line);
	  			String[] columns = line.split(";");
//	  			columns[13] = "Register, reload or check the balance of your jambacard online at "
//	  					+ "www.jambajuice.com or call 1866-4R-FRUIT. This jambacard, is reloadable and may only "
//	  					+ "be used to purchase goods at participating Jamba Juice locations. Unless otherwise "
//	  					+ "required or limited by law, this card is not redeemable for cash. Your jambacard may "
//	  					+ "not be replaced if it is lost, stolen or destroyed unless you register it first at "
//	  					+ "www.jambajuice.com. Note: Proof of purchase and/or registration may be required for "
//	  					+ "card replacement. To obtain additional terms and a list of participating locations, "
//	  					+ "visit us at www.jambajuice.com or call 1866-4R-FRUIT. Issued by Jamba Juice Company.";
//	  			String rec = "";
//	  			for(String col: columns) {
//	  				rec = rec + col + ";";
//	  			}
//	  			rec = rec.substring(0, rec.length() - 2);
//	  			bw.write(rec);
//  				bw.newLine();
  		
	  			//UUID id = UUID.randomUUID();
	  			UUID id = UUID.fromString(columns[0]);
	  			System.out.println("reward_uid: " + columns[0]);
	  			System.out.println("merchant_name: " + columns[1]);
	  			System.out.println("reward_item_name: " + columns[2]);
	  			System.out.println("reward_type: " + columns[3]);
	  			System.out.println("info_description: " + columns[4]);
	  			System.out.println("long_description: " + columns[5]);
	  			System.out.println("landing_page_thumbnail_url: " + columns[6]);
	  			System.out.println("reward_item_thumbnail_url: " + columns[7]);
	  			System.out.println("reward_item_image_url: " + columns[8]);
	  			System.out.println("reward_value: " + columns[9]);
	  			System.out.println("validity_start: " + columns[10]);
	  			System.out.println("validity_end: " + columns[11]);
	  			System.out.println("is_valid: " + columns[12]);
	  			System.out.println("disclaimer: " + columns[13]);
	  			System.out.println("barcode_url: " + columns[14]);
	  			System.out.println("barcode_id: " + columns[15]);
	  			System.out.println("barcode_pin: " + columns[16]);
	  		  	Insert insert = QueryBuilder
	  		            .insertInto("payl", "reward")
	  		            .value("reward_uid", id)
	  		            .value("merchant_name", columns[1])
	  		            .value("reward_item_name", columns[2])
	  		            .value("reward_type", columns[3])
	  		            .value("info_description", columns[4])
	  		            .value("long_description", columns[5])
	  		            .value("landing_page_thumbnail_url", columns[6])
	  		            .value("reward_item_thumbnail_url", columns[7])
	  		            .value("reward_item_image_url", columns[8])
	  		            .value("reward_value", columns[9])
	  		            .value("validity_start", columns[10])
	  		            .value("validity_end", columns[11])
	  		            .value("is_valid", Boolean.valueOf(columns[12]))
	  		            .value("disclaimer", columns[13])
	  		            .value("barcode_url", columns[14])
	  		            .value("barcode_id", columns[15])
	  		            .value("barcode_pin", columns[16]);
	  		    session.execute(insert.toString());
	  			line = br.readLine();
	  		}
	  	}
	  	catch (IOException ioe) { 
	  			ioe.printStackTrace(); 
	  	}
		finally {
			try {
				if (br != null) br.close();
//				if (bw != null) bw.close();
//				if (fw != null) fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
	
		}
	}
}
