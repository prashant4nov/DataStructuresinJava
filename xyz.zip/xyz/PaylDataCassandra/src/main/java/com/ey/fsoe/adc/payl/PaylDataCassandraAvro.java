package com.ey.fsoe.adc.payl;

import com.datastax.driver.core.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import kafka.serializer.DefaultDecoder;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaPairInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka.KafkaUtils;
import com.datastax.driver.core.LocalDate;
import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.twitter.bijection.Injection;
import com.twitter.bijection.avro.GenericAvroCodecs;

import kafka.serializer.StringDecoder;

public class PaylDataCassandraAvro {

	private static Injection<GenericRecord, byte[]> recordInjection;
	private static final String USER_SCHEMA = "{" 
			+ "\"namespace\":\"example.avro\"," 
			+ "\"type\":\"record\"," 
			+ "\"name\":\"UserProfileEvent\"," 
			+ "\"fields\":["
			+ "  { \"name\":\"eventId\", \"type\":\"string\" }," 
			+ "  { \"name\":\"eventType\", \"type\":\"string\" },"
			+ "  { \"name\":\"optType\", \"type\":\"string\" },"
			+ "  { \"name\":\"id\", \"type\":\"string\" }," 
			+ "  { \"name\":\"external_user_id\", \"type\":\"string\" },"
			+ "  { \"name\":\"health_id\", \"type\":\"string\" },"
			+ "  { \"name\":\"first_name\", \"type\":\"string\" },"
			+ "  { \"name\":\"last_name\", \"type\":\"string\" }," 
			+ "  { \"name\":\"email\", \"type\":\"string\" },"
			+ "  { \"name\":\"driver_license\", \"type\":\"string\" },"
			+ "  { \"name\":\"gender\", \"type\":\"string\" }," 
			+ "  { \"name\":\"status\", \"type\":\"string\" },"
			+ "  { \"name\":\"application_type\", \"type\":\"string\" },"
			+ "  { \"name\":\"display_name\", \"type\":\"string\" },"
			+ "  { \"name\":\"mobile_phone\", \"type\":\"string\" },"
			+ "  { \"name\":\"office_phone\", \"type\":\"string\" },"
			+ "  { \"name\":\"home_phone\", \"type\":\"string\" },"
			+ "  { \"name\":\"language\", \"type\":\"string\" },"
			+ "  { \"name\":\"promotional_email\", \"type\":\"string\" },"
			+ "  { \"name\":\"date_of_birth\", \"type\":\"string\" },"
			+ "  { \"name\":\"street_number\", \"type\":\"string\" },"
			+ "  { \"name\":\"street_name\", \"type\":\"string\" }," 
			+ "  { \"name\":\"city\", \"type\":\"string\" },"
			+ "  { \"name\":\"country\", \"type\":\"string\" }," 
			+ "  { \"name\":\"state\", \"type\":\"string\" },"
			+ "  { \"name\":\"zip_code\", \"type\":\"string\" },"
			+ "  { \"name\":\"appartment\", \"type\":\"string\" }," 
			+ "  { \"name\":\"weight\", \"type\":\"string\" },"
			+ "  { \"name\":\"body_type\", \"type\":\"string\" },"
			+ "  { \"name\":\"pregnancy_details\", \"type\":\"string\" },"
			+ "  { \"name\":\"disability_details\", \"type\":\"string\" },"
			+ "  { \"name\":\"pregnancy_status\", \"type\":\"string\" },"
			+ "  { \"name\":\"disability_status\", \"type\":\"string\" },"
			+ "  { \"name\":\"created\", \"type\":\"string\" }," 
			+ "  { \"name\":\"updated\", \"type\":\"string\" }"
			+ "]}";
	static Cluster cluster;
	static Session session;
	static {
		Schema.Parser parser = new Schema.Parser();
		Schema schema = parser.parse(USER_SCHEMA);
		recordInjection = GenericAvroCodecs.toBinary(schema);
		// Connect to the cluster and keyspace "demo"
		//cluster = Cluster.builder().addContactPoint("127.0.0.1").build();
		cluster = Cluster.builder().addContactPoint("10.246.65.71").build();
		session = cluster.connect("payl");
	}
	
	public static LocalDate getDate(String startDateString) {
		DateFormat df = new SimpleDateFormat("yyyy-mm-dd"); 
		java.util.Date startDate;
		String newDateString;
		List<String> date = null;
		try {
		    startDate = df.parse(startDateString);
		    newDateString = df.format(startDate);
		    date = Arrays.asList(newDateString.split("-"));
		} catch (ParseException e) {
		    e.printStackTrace();
		}
		
		LocalDate d = LocalDate.fromYearMonthDay(
				Integer.parseInt(date.get(0)), 
				Integer.parseInt(date.get(1)), 
				Integer.parseInt(date.get(2)));
		
		return d;

	}

	public static void main(String[] args) throws InterruptedException {
		// StreamingExamples.setStreamingLogLevels();
		SparkConf sparkConf = new SparkConf().setAppName("PaylSparkWithSpringDataCassandra")
				.set("spark.driver.host", "10.246.65.84");
				//.set("spark.driver.host", "localhost");
		// Create the context with 2 seconds batch size

		JavaSparkContext sc = new JavaSparkContext(sparkConf);
		JavaStreamingContext jssc = new JavaStreamingContext(sc, new Duration(2000));

		// processing pipeline
		Map<String, String> kafkaParams = new HashMap<>();
		//kafkaParams.put("metadata.broker.list", "localhost:9092");
		kafkaParams.put("metadata.broker.list", "10.246.65.82:9092");
		Set<String> topics = Collections.singleton("UserProfileTopic");

		JavaPairInputDStream<String, byte[]> directKafkaStream = KafkaUtils.createDirectStream(jssc, String.class,
				byte[].class, StringDecoder.class, DefaultDecoder.class, kafkaParams, topics);

		directKafkaStream.map(message -> recordInjection.invert(message._2).get()).foreachRDD(rdd -> {
			rdd.foreach(record -> {
				System.out.println("str1====== " + record.get("external_user_id") + ", street_number====== "
						+ record.get("street_number"));

				LocalDate dd = LocalDate.fromYearMonthDay(2104, 12, 1);

				String uid = record.get("id").toString();
				//UUID uid = UUID.fromString(id);
				String external_user_id = record.get("external_user_id").toString();
				String health_id = record.get("health_id").toString();
				String first_name = record.get("first_name").toString();
				String last_name = record.get("last_name").toString();
				String email = record.get("email").toString();
				String driver_license = record.get("driver_license").toString();
				String gender = record.get("gender").toString();
				String status = record.get("status").toString();
				String application_type = record.get("application_type").toString();

				String display_name = record.get("display_name").toString();
				String mobile_phone = record.get("mobile_phone").toString();
				String office_phone = record.get("office_phone").toString();
				String home_phone = record.get("home_phone").toString();
				String language = record.get("language").toString();
				String promotional_email = record.get("promotional_email").toString();
				// TODO: remove the hard coded street number and weight.
				String street_number = record.get("street_number").toString();
				//int st_n = Integer.parseInt(street_number);
				String street_name = record.get("street_name").toString().trim();
				String city = record.get("city").toString();
				String country = record.get("country").toString();
				String state = record.get("state").toString();
				String zip_code = record.get("zip_code").toString();
				String apartment = record.get("appartment").toString();
				String weight = record.get("weight").toString();
				String body_type = record.get("body_type").toString();
				String pregnancy_details = record.get("pregnancy_details").toString();
				String disability_details = record.get("disability_details").toString();
				String pregnancy_status = record.get("pregnancy_status").toString();
				String disability_status = record.get("disability_status").toString();

				//UUID ui = UUID.fromString("28400000-8cf0-11bd-b23e-10b96e4ef00d");
				String created = record.get("created").toString();
				String updated = record.get("updated").toString();
				String dob = record.get("date_of_birth").toString();
				LocalDate d = LocalDate.fromYearMonthDay(2104, 12, 1);

				// Insert one record into the users table
				Insert insert = QueryBuilder.insertInto("payl", "user").value("id", uid).value("appartment", apartment)
						.value("application_type", application_type).value("street_name", street_name)
						.value("display_name", display_name).value("last_name", last_name)
						.value("first_name", first_name).value("disability_status", Boolean.valueOf(disability_status))
						.value("pregnancy_status", Boolean.valueOf(pregnancy_status))
						.value("disability_details", disability_details).value("pregnancy_details", pregnancy_details)
						.value("body_type", body_type).value("city", city).value("country", country)
						.value("date_of_birth", getDate(dob)).value("created", getDate(created)).value("driver_license", driver_license)
						.value("email", email).value("external_id", external_user_id).value("gender", gender)
						.value("health_id", health_id).value("home_phone", home_phone).value("language", language)
						.value("mobile_phone", mobile_phone).value("office_phone", office_phone)
						.value("promotional_email", promotional_email).value("state", state).value("status", status)
						.value("street_number", (street_number.equals("NA")) ? 0 : Integer.parseInt(street_number)).value("updated", getDate(updated))
						.value("weight", (weight.equals("NA")) ? 0 : Integer.parseInt(weight)).value("zip_code", zip_code);
				session.execute(insert.toString());

			});
		});

		jssc.start();
		jssc.awaitTermination();
	}
}











































