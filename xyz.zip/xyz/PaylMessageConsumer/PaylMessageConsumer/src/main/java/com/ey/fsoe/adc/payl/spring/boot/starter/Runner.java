package com.ey.fsoe.adc.payl.spring.boot.starter;

/**
 * @author kadamab
 *
 */

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.ey.fsoe.adc.payl.rabbitmq.Receiver;

@Component
public class Runner implements CommandLineRunner {

    private final Receiver receiver;

    public Runner(Receiver receiver) {
        this.receiver = receiver;
    }
    
    public void run(String... args) throws Exception {
    	this.receiver.getLatch().await();
    } 

}
