/**
 * 
 */
package com.ey.fsoe.adc.payl.rabbitmq;

import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import example.avro.UserProfileEvent;
import example.avro.ActivityEvent;
import example.avro.RewardRedemptionEvent;
import example.avro.CoinDepositEvent;
/**
 * @author kadamab
 *
 */

public class Utility {
	private static final Logger LOGGER = LoggerFactory.getLogger(Receiver.class);
	public UserProfileEvent createProfileEvent(String optType, Map<String, Object> userMap, 
			Map<String, Object> healthMap, Map<String, Object> addressMap) {
		
		LOGGER.info("createProfileEvent() method from Utilty Class");
		UUID eventId = UUID.randomUUID();
        UserProfileEvent userProfileEvent = UserProfileEvent.newBuilder().setEventId(eventId.toString()).setOptType(optType)
				.setEventType("UserProfile")
				.setId(userMap.get("id").toString())
				.setExternalId(userMap.get("external_user_id").toString()).setHealthId(userMap.get("health_id").toString())
				.setFirstName(userMap.get("first_name").toString()).setLastName(userMap.get("last_name").toString())
				.setEmail(userMap.get("email").toString()).setDriverLicense(userMap.get("driver_license").toString())
				.setGender(userMap.get("gender").toString()).setStatus(userMap.get("status").toString())
				.setApplicationType(userMap.get("application_type").toString())
				.setDisplayName(userMap.get("display_name").toString())
				.setMobilePhone(userMap.get("mobile_phone").toString())
				.setOfficePhone(userMap.get("office_phone").toString())
				.setHomePhone(userMap.get("home_phone").toString()).setLanguage(userMap.get("language").toString())
				.setPromotionalEmail(userMap.get("promotional_email").toString())
				.setDateOfBirth(userMap.get("date_of_birth").toString())
				.setStreetNumber(addressMap.get("street_number").toString())
				.setStreetName(addressMap.get("street_name").toString()).setCity(addressMap.get("city").toString())
				.setCountry(addressMap.get("country").toString()).setState(addressMap.get("state").toString())
				.setZipCode(addressMap.get("zip_code").toString()).setAppartment(addressMap.get("appartment").toString())
				.setWeight(healthMap.get("weight").toString()).setBodyType(healthMap.get("body_type").toString())
				.setPregnancyDetails(healthMap.get("pregnancy_details").toString())
				.setDisabilityDetails(healthMap.get("disability_details").toString())
				.setPregnancyStatus(healthMap.get("pregnancy_status").toString())
				.setDisabilityStatus(healthMap.get("disability_status").toString())
				.setCreated(userMap.get("created").toString()).setUpdated(userMap.get("updated").toString())
				.build();
        return userProfileEvent;
	}
	
	public ActivityEvent createActivityEvent(Map<String, Object> activityMap) {
		UUID eventId = UUID.randomUUID();
		LOGGER.info("createActivityEvent() method from Utilty Class");
        ActivityEvent activityEvent = ActivityEvent.newBuilder().setEventId(eventId.toString())
        		.setOptType("Create")
				.setEventType("Activity")
				.setActivityId(activityMap.get("activity_id").toString())
				.setExternalId(activityMap.get("external_id").toString())
				.setActivityType(activityMap.get("activity_type").toString())
				.setActivityCategory(activityMap.get("activity_category").toString())
				.setDuration(activityMap.get("duration").toString())
				.setStartTime(activityMap.get("start_time").toString())
				.setIntensity(activityMap.get("intensity").toString())
				.setDistance(activityMap.get("distance").toString())
				.setCalories(activityMap.get("calories").toString())
				.setSource(activityMap.get("source").toString())
				.setCreated(activityMap.get("created").toString())
				.setUpdated(activityMap.get("updated").toString())
				.setUtcOffset(activityMap.get("utc_offset").toString())	
				.build();  
        return activityEvent;
	}
	
	public RewardRedemptionEvent createRewardRedemptionEvent(Map<String, Object> rewardMap) {
		  UUID eventId = UUID.randomUUID();
		  LOGGER.info("createRewardRedemptionEvent() method from Utilty Class");
	        RewardRedemptionEvent redemptionEvent = RewardRedemptionEvent.newBuilder().setEventId(eventId.toString())
	        		.setOptType("Create")
					.setEventType("RewardRedemption")
					.setExternalUserId(rewardMap.get("external_user_id").toString())
					.setDateTime(rewardMap.get("date_time").toString())
					.setRewardId(rewardMap.get("reward_id").toString())
					.setCoinsDeducted(rewardMap.get("coins_deducted").toString())
					.setBalance(rewardMap.get("balance").toString()) 	
					.build(); 
	        return redemptionEvent;
	}
	
	public CoinDepositEvent createCoinDepositEvent(Map<String, Object> coinsMap) {
		  UUID eventId = UUID.randomUUID();
		  LOGGER.info("createCoinDepositEvent() method from Utilty Class");
	         CoinDepositEvent coinDepositEvent = CoinDepositEvent.newBuilder().setEventId(eventId.toString())
	         		.setOptType("Update")
	 				.setEventType("CoinDeposit")
	 				.setId(coinsMap.get("id").toString())
	 				.setExternalUserId(coinsMap.get("external_user_id").toString())
	 				.setDateTime(coinsMap.get("date_time").toString())
	 				.setDepositDescription(coinsMap.get("deposit_description").toString())
	 				.setAmount(coinsMap.get("amount").toString())
	 				.setBalance(coinsMap.get("balance").toString()) 	
	 				.build(); 
	         return coinDepositEvent;
	}

}
