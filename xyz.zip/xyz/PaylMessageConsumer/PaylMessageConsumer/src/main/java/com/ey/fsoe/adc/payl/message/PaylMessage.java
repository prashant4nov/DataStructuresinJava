/**
 * 
 */
package com.ey.fsoe.adc.payl.message;

/**
 * @author kadamab
 *
 */
public abstract class PaylMessage {

}
