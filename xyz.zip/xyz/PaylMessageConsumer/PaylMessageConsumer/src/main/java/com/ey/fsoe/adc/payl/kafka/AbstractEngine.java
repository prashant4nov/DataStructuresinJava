package com.ey.fsoe.adc.payl.kafka;

import com.ey.fsoe.adc.payl.event.PaylEvent;

/**
 * @author kadamab
 *
 */

	public class AbstractEngine<T extends PaylEvent<?>> {

		// TODO: all the initialization code for topic name for kafka etc goes here
		public void initialize(){
			
		}
		
		//TODO: consumer, producer code for kafka goes here
		public void processEvent(){
			
		}
	}
