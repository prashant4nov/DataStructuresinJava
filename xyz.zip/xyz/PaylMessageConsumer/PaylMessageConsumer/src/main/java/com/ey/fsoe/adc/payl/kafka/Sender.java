package com.ey.fsoe.adc.payl.kafka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.core.KafkaTemplate;

import example.avro.PaylEvent;
import example.avro.ActivityEvent;
import example.avro.UserProfileEvent;

public class Sender<T> {

  private static final Logger LOGGER = LoggerFactory.getLogger(Sender.class);

  @Value("${kafka.topic.avro}")
  private String avroTopic;
  
  @Autowired
  private KafkaTemplate<String, T> kafkaTemplate;

  public void send(T event) {
    LOGGER.info("sending event='{}'", event.toString());
System.out.println("AvroTopic ::" + avroTopic);	
    kafkaTemplate.send(avroTopic, event);
  }
  
}
