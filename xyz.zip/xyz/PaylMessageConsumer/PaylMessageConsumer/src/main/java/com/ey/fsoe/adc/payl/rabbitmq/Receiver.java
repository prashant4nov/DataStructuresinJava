package com.ey.fsoe.adc.payl.rabbitmq;

/**
 * @author kadamab
 *
 */
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import example.avro.ActivityEvent;
import example.avro.UserProfileEvent;
import example.avro.RewardRedemptionEvent;
import example.avro.CoinDepositEvent;
import java.util.concurrent.CountDownLatch;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ey.fsoe.adc.payl.kafka.Sender;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.core.type.TypeReference;


@Component
public class Receiver implements MessageListener{

	private static final Logger LOGGER = LoggerFactory.getLogger(Receiver.class);
	
	@Autowired
	private Sender sender;
	
	@Autowired
	private ProcessEngine  processEngine;
	
	private CountDownLatch latch = new CountDownLatch(1);
	
	public void onMessage(Message message) {
		LOGGER.info("onMessage() method for PaylMessageConsumer");
		LOGGER.info("Received message='{}'", message.toString());
		this.processEngine.processEvent(message);
    }
	
	/*
	public void setValues(Map<String,Object> userMap){
		for(Map.Entry<String, Object> entry : userMap.entrySet()){
			System.out.println(entry.getKey() + "/" + entry.getValue());
		}
	} */

	public CountDownLatch getLatch() {
		return latch;
	}
	


}

