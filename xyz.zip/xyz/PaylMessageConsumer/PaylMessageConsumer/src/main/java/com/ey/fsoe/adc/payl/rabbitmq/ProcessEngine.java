package com.ey.fsoe.adc.payl.rabbitmq;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.beans.factory.annotation.Autowired;

import com.ey.fsoe.adc.payl.kafka.Sender;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ey.fsoe.adc.payl.kafka.Sender;

import example.avro.ActivityEvent;
import example.avro.UserProfileEvent;
import example.avro.CoinDepositEvent;
import example.avro.RewardRedemptionEvent;

/**
 * @author kadamab
 *
 */

public class ProcessEngine {
	
	@Autowired
	private Sender sender;
	
	@Autowired
	private Utility utility;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Receiver.class);
	
	public void processEvent(Message message) {
		Map<String, Object> headers = message.getMessageProperties().getHeaders();
		String messageType = null;
		String mbody = new String(message.getBody());

		for (Map.Entry<String, Object> header : headers.entrySet()) {
			if (header.getKey().equalsIgnoreCase("message-type"))
				messageType = header.getValue().toString();
		}

		if (messageType.equalsIgnoreCase("user.created") || messageType.equalsIgnoreCase("user.updated")) {
			this.sendUserPayload(message);
		}

		else if (messageType.equalsIgnoreCase("activity")) {
			this.sendActivityPayload(message);
		}

		else if (messageType.equalsIgnoreCase("reward_redeem")) {
			this.sendRewardPayload(message);
		}

		else if (messageType.equalsIgnoreCase("coins_deposit")) {
			this.sendCoinDepositPayload(message);
		}
	}
	
	public void checkForNull(Map<String, Object> m) {
		System.out.println("Check for null method:: ");
		Iterator<Entry<String, Object>> it = m.entrySet().iterator();
		    while (it.hasNext()) {
		        Map.Entry<String, Object> pair = (Map.Entry<String, Object>)it.next();

		        if(pair.getValue()==null){
		        	pair.setValue("NA");
		        }  
		    }
	}
	
	public void sendUserPayload(Message message){
		Map<String, Object> headers = message.getMessageProperties().getHeaders();
		String messageType = null;
		String mbody = new String(message.getBody());

		for (Map.Entry<String, Object> header : headers.entrySet()) {
			if (header.getKey().equalsIgnoreCase("message-type"))
				messageType = header.getValue().toString();
		}
		
		 ObjectMapper mapper = new ObjectMapper();
         Map<String, Object> userMap = null;
         
         try { 
         		userMap = mapper.readValue(mbody, new TypeReference<Map<String, Object>>() {});	
         }
         
         catch(Exception e){}
         
         //Building the health object 
         JSONObject healthObject = (JSONObject) JSONValue.parse(mbody);
         String healthBody = healthObject.get("health").toString();
         
         ObjectMapper hmapper = new ObjectMapper();
         Map<String, Object> healthMap = null;
         
         try{ 
         	healthMap = mapper.readValue(healthBody, new TypeReference<Map<String, Object>>() {
 		});
 		
         }
         catch(Exception e){}

         // end health object
         
         //to build a Address object 
         JSONObject addressObject = (JSONObject) JSONValue.parse(mbody);
         String addressBody = addressObject.get("address").toString();        
         
         ObjectMapper amapper = new ObjectMapper();
         Map<String, Object> addressMap = null;
         
         try{ 
         	addressMap = mapper.readValue(addressBody, new TypeReference<Map<String, Object>>() {});
         }
         catch(Exception e){}
         
         // end address object
         
         String optType = null;
         
         if(messageType.equalsIgnoreCase("user.created")){
         	optType = "Create";
         }
         else{
         	optType = "Update";
         }
         
         UserProfileEvent userProfileEvent = this.utility.createProfileEvent(optType, userMap, healthMap, addressMap);
         
 		sender.send(userProfileEvent);
 		LOGGER.info("Sent Event ='{}'", userProfileEvent);
	}
	
	public void sendActivityPayload(Message message){
		String mbody = new String(message.getBody());
		ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> activityMap = null;
        
        try{ 
        	activityMap = mapper.readValue(mbody, new TypeReference<Map<String, Object>>() {});
        }
        catch(Exception e){}
        
        this.checkForNull(activityMap);
        
        ActivityEvent activityEvent = this.utility.createActivityEvent(activityMap);
    
    
		sender.send(activityEvent);
		LOGGER.info("Sent Event ='{}'", activityEvent);
	}
	
	public void sendRewardPayload(Message message) {
		String mbody = new String(message.getBody());
		ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> rewardMap = null;
        
        try{ 
        	rewardMap = mapper.readValue(mbody, new TypeReference<Map<String, Object>>() {});  		
        }
        catch(Exception e){}
        
        RewardRedemptionEvent redemptionEvent = this.utility.createRewardRedemptionEvent(rewardMap);
   
		sender.send(redemptionEvent);
		LOGGER.info("Sent Event ='{}'", redemptionEvent);
	}
	
	public void sendCoinDepositPayload(Message message) {
		String mbody = new String(message.getBody());
		 ObjectMapper mapper = new ObjectMapper();
         Map<String, Object> coinsMap = null;
         
         try { 
         		coinsMap = mapper.readValue(mbody, new TypeReference<Map<String, Object>>() {});  		
         }
         catch(Exception e){}
         
         CoinDepositEvent coinDepositEvent = this.utility.createCoinDepositEvent(coinsMap);
         
 		sender.send(coinDepositEvent);
 		LOGGER.info("Sent Event ='{}'", coinDepositEvent);
     }
	
}
