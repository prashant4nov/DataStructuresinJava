package com.ey.fsoe.adc.payl.event;

import com.ey.fsoe.adc.payl.message.PaylMessage;

/**
 * @author kadamab
 *
 */
public class PaylEvent<T extends PaylMessage> {
	
	private long eventId;
	private String eventType;
	private String operationType;
	private String payload;
	
	public long getEventId() {
		return eventId;
	}
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getOperationType() {
		return operationType;
	}
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
	

}
