docker run -p 7474:7474 -p 7687:7687 --env=NEO4J_AUTH=none --name neo4j --volume=/tmp:/data neo4j:latest

Docker stop neo4j

Docker rm neo4j
1979-07-01


Documents/payl.2.6    - feb 6th

sudo /usr/local/spark/bin/spark-submit --master local[*] --class com.ey.fsoe.adc.payl.PaylDataCassandraAvro PaylDataCassandra-0.0.1-fat.jar > PaylDataCassandra.log 2>&1 &

sudo nohup /usr/local/spark/bin/spark-submit --jars spark-streaming-kafka-0-8-assembly_2.10-2.0.0-preview.jar,spark-core_2.11-1.5.2.logging.jar ./activity-job-spark.py > activity-job-spark.log 2>&1

/usr/lib/jvm/java-8-oracle/jre/bin/java -cp /usr/local/spark/conf/:/usr/local/spark/jars/* -Xmx1g org.apache.spark.deploy.SparkSubmit --master local[*] --class com.ey.fsoe.adc.payl.PaylDataCassandraAvro PaylDataCassandra-0.0.1-fat.jar


kafka client is the library api that we install
kafka broker is the server of kafka
cassandra: /Users/kumarpr15/dsc-cassandra-3.0.9/bin
https://www.kaggle.com/competitions
UserProfileTopic
ActivityDataTopic
HealthScoreTopic
RewardsRedemptionTopic
    
http://teleadmin.sandbox.basedrive.baselinetelematics.com:15672/#/queues/ey/ey_payl_scores

http://teleadmin.sandbox.basedrive.baselinetelematics.com:15672/#/queues/ey/ey_payl_data

http://teleadmin.sandbox.basedrive.baselinetelematics.com:15672/#/queues/ey/ey_userfeed




https://dtflaneur.wordpress.com/2015/10/05/installing-kafka-on-mac-osx/
  start zookeeper: zkserver start
  start kafka: 
1. /usr/local/Cellar/kafka/0.11.0.1/bin
2. kafka-server-start /usr/local/etc/kafka/server.properties
3. Create topic: kafka-topics --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic UserProfileTopic
4. kafka-topics --list --zookeeper localhost:2181
5. create keyspace payl with replication = {‘class’: ‘SimpleStrategy’, ‘replication_factor’: 2} ;
6. http://teleadmin.sandbox.basedrive.baselinetelematics.com:15672/#/queues/ey/ey_userfeed

http://teleadmin.sandbox.basedrive.baselinetelematics.com:15672/#/queues/ey/payl_data

ey_payl_scores

http://teleadmin.sandbox.basedrive.baselinetelematics.com:15672/#/queues/ey/ey_payl_scores

http://teleadmin.sandbox.basedrive.baselinetelematics.com:15672/#/queues/ey/ey_payl_data



 start zookeeper: bin/zookeeper-server-start.sh config/zookeeper.properties
 start kafka: bin/kafka-server-start.sh config/server.properties
 creating topics: bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 —partitions 1 --topic <topic_name>

For the mvp I have kept the replication-factor and paritions 1 but later on we can increase those values depending on the requirements. reference link: https://kafka.apache.org/documentation/#replication 

bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 —-topic user_profile 
bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 —-topic user_activity
bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 —-topic score  

/Users/kumarpr15/Downloads/rabbitmq-amqp-tutorials-producer/target

/Users/kumarpr15/Documents/payl-pro/payl-mvp/paylRabbitMQKafka/target

command to check kafka topics created: 
./bin/kafka-topics.sh --list --zookeeper localhost:2181

http://feed.baseline.info:15672/#/queues/ey/userfeed

ps -ef | grep -i kafka

kill process_id

https://blog.cloudera.com/blog/2009/11/avro-a-new-format-for-data-interchange/

rabbitmq start usr/local/opt/rabbitmq/sbin.  :  ./rabbitmq-server

pwd
1979-07-01

Kafka broker 0 --> 10.246.65.82. 10.246.65.82:9092
Spark master --> 10.246.65.84 - in /home/spark -&gt; activity-job-spark -&gt; tail -f&nbsp;activity-job-spark.log

cass node 0 --> 10.246.65.71  
vm -> 10.246.65.77 for vm code

internal dev machine: 10.246.65.68 -> paylconsumer running ->  tail -f /var/log/activityconsumer.out.log

but using cassandra 71 and kafka 82

cd /var/log
tail -f /var/log/userprofileconsumer.out.log

sudo nohup /usr/local/spark/bin/spark-submit --master local[*] --class com.ey.fsoe.adc.payl.PaylDataCassandraAvro PaylDataCassandra-0.0.1-fat.jar



1. MockRabbitProducer  2. PaylMessageConsumer (: activity: vi application-activity.properties)  3. PaylMessageProducer (healthscore)

java -Dspring.profiles.active=activity -jar MockRabbitProducer-0.0.1-SNAPSHOT.jar
healthscore

userprofile

http://feed.baseline.info:15672/#/queues

https://confluence.baselinetelematics.com/display/PAYL/Activity+Data+Feed


cqlsh 10.246.65.71

kafka commands:
ssh adc@10.246.65.82

kafka.bootstrap-servers=10.246.65.82:9092
kafka.topic.avro=ActivityDataTopic

adc@ACUSNLDKFKA1:~$ sudo su kafka
kafka@ACUSNLDKFKA1:/home/adc$ cd 
kafka@ACUSNLDKFKA1:~$ cd kafka
kafka@ACUSNLDKFKA1:~/kafka$ ls

delete kafka topics: ./kafka-topics.sh --delete --zookeeper localhost:2181 --topic <topic_name>

to check kafka topics installed: kafkat partitions 
./pyspark --jars $/Users/kumarpr15/Downloads/spark-2.1.1/pyspark_cassandra-0.3.5.jar --driver-class-path 

/Users/kumarpr15/Downloads/spark-2.1.1

spark on cloud
->sudo nmap -p 9042 10.246.65.71

->scp /Users/kumarpr15/Downloads/spark-2.1.1/scp/* adc@10.246.65.84:~/home/adc

scp PaylDataCassandra-0.0.1-fat.jar adc@10.246.65.84:~/


->/usr/local/spark/bin/spark-submit --jars spark-streaming-kafka-0-8-assembly_2.10-2.0.0-preview.jar,spark-core_2.11-1.5.2.logging.jar ./activity-job-spark.py

ctrl + R 

 ./bin/pyspark --jars pyspark_cassandra-0.3.5.jar --driver-class-path client

bin/spark-submit --jars spark-streaming-kafka-0-8-assembly_2.10-2.0.0-preview.jar,spark-core_2.11-1.5.2.logging.jar /Users/kumarpr15/payl_inti/payl-mvp/HealthScore/spark_kafka_cassandra_stream.py

bin/spark-submit --jars spark-streaming-kafka-0-8-assembly_2.10-2.0.0-preview.jar,spark-core_2.11-1.5.2.logging.jar /Users/kumarpr15/payl_inti/payl-mvp/HealthScore/activity-job-spark.py

bin/spark-submit --master local[*] --class com.ey.fsoe.adc.payl.PaylDataCassandraAvro PaylDataCassandra-0.0.1.jar.original

mvn clean install
mvn clean package

- command to see contents of jar: jar -tvf PaylDataCassandra-0.0.1.jar | grep PaylDataCassandraAvro

bin/spark-submit --master local[*] --jars spring-boot-1.2.3.RELEASE.jar,bijection-core_2.12-0.9.5.jar,bijection-avro_2.12-0.9.5.jar,cassandra-driver-core-3.0.0-alpha5.jar,guava-19.0.jar --class com.ey.fsoe.adc.payl.PaylDataCassandraAvro PaylDataCassandra-0.0.1.jar.original



http://www.datasciencebytes.com/bytes/2016/04/18/getting-started-with-spark-running-a-simple-spark-job-in-java/

bin/spark-submit --packages org.apache.spark:spark-streaming-kafka-0-8_2.11:2.2.0,com.databricks:spark-avro_2.11:3.2.0 --jars spark-core_2.11-1.5.2.logging.jar /Users/kumarpr15/payl_inti/payl-mvp/HealthScore/spark_kafka_cassandra_stream.py

USC02SX20ZHF1T:spark-2.1.0 kumarpr15$ bin/spark-submit --packages org.apache.spark:spark-streaming-kafka-0-8_2.11:2.2.0,com.databricks:spark-avro_2.11:3.2.0 --jars spark-core_2.11-1.5.2.logging.jar /Users/kumarpr15/payl_inti/payl-mvp/HealthScore/spark_kafka_cassandra_stream.py
bin/spark-submit --jars


spark-streaming-kafka-assembly_2.10-1.6.3.jar 

spark_kafka_cassandra_stream.py 



bin/spark-submit --jars spark-streaming-kafka-assembly_2.10-1.6.3.jar,spark-core_2.11-1.5.2.logging.jar spark_kafka_cassandra_stream.py


https://stackoverflow.com/questions/35414677/saving-data-back-into-cassandra-as-rdd

https://github.com/joshmarshall/cassandra-python-driver/blob/master/example.py


avro schemaL: 

http://working-with-data.blogspot.com/2014/03/avro-simple-example.html

cp source destination
cp ~/Downloads

cp /home/adc/file_name .






https://github.com/dpkp/kafka-python/issues/362

https://github.com/dpkp/kafka-python/issues/1046


updated date: 2018-01-01T02:00:00Z
Traceback (most recent call last):
  File "/home/spark/healthscore/./activity-job-spark.py", line 148, in <module>
    producer.send_messages(topic, raw_bytes)
  File "/home/spark/healthscore/./activity-job-spark.py", line 145, in main
    try:
  File "/usr/local/lib/python2.7/dist-packages/kafka/producer/simple.py", line 50, in send_messages
    topic, partition, *msg
  File "/usr/local/lib/python2.7/dist-packages/kafka/producer/base.py", line 380, in send_messages
    return self._send_messages(topic, partition, *msg)
  File "/usr/local/lib/python2.7/dist-packages/kafka/producer/base.py", line 423, in _send_messages
    fail_on_error=self.sync_fail_on_error
  File "/usr/local/lib/python2.7/dist-packages/kafka/client.py", line 653, in send_produce_request
    (not fail_on_error or not self._raise_on_response_error(resp))]
  File "/usr/local/lib/python2.7/dist-packages/kafka/client.py", line 409, in _raise_on_response_error
    raise resp
kafka.errors.FailedPayloadsError: FailedPayloadsError


cassandra 3.0.9


Spark 2.2.0

Kafka 2.11

RabbitMQ 3.3.5


sudo nohup /usr/local/spark/bin/spark-submit --master local[*] --class com.ey.fsoe.adc.payl.PaylDataCassandraAvro PaylDataCassandra-0.0.1-fat.jar > PaylDataCassandra.log 2>&1


sudo nohup /usr/local/spark/bin/spark-submit --jars spark-streaming-kafka-0-8-assembly_2.10-2.0.0-preview.jar,spark-core_2.11-1.5.2.logging.jar ./activity-job-spark.py > activity-job-spark.log 2>&1







sudo nohup /usr/local/spark/bin/spark-submit --jars spark-streaming-kafka-0-8-assembly_2.10-2.0.0-preview.jar,spark-core_2.11-1.5.2.logging.jar ./activity-job-spark.py > activity-job-spark.log 2>&1 &


screen

screen -r

cd space enter takes to hgomew
supervisor -> like nohup 


1. java spark submit
2. muscle score
3. test cases
4. refactoring
5. save health score to table
6. update using spark streaming
7. weekly score: 
8. get user age from the table + evaluation date






1. User profile - send from mock 
2. Activity data - send from mock

CREATE TABLE payl.user (
    id text PRIMARY KEY,
    appartment text,
    application_type text,
    body_type text,
    city text,
    coins int,
    country text,
    created date,
    date_of_birth date,
    disability_details text,
    disability_status boolean,
    display_name text,
    driver_license text,
    email text,
    external_id text,
    first_name text,
    gender text,
    health_id text,
    home_phone text,
    language text,
    last_name text,
    mobile_phone text,
    office_phone text,
    pregnancy_details text,
    pregnancy_status boolean,
    promotional_email text,
    state text,
    status text,
    street_name text,
    street_number int,
    updated date,
    weight int,
    zip_code text


  create table user (id text primary key, external_user_id text, health_id text, first_name text, last_name text, email text, driver_license text, gender text, status text, application_type text, display_name text, mobile_phone text, office_phone text, home_phone text, date_of_birth text, language text, promotional_email text, created text, updated text, street_number text, street_name text, city text, country text, state text, zip_code text, appartment text, weight text, body_type text, pregnancy_status text, pregnancy_details text, disability_status text, disability_details text, coins text); 





1. MockRabbitProducer  2. PaylMessageConsumer (: activity: vi application-activity.properties)  3. PaylMessageProducer (healthscore)

java -Dspring.profiles.active=activity -jar MockRabbitProducer-0.0.1-SNAPSHOT.jar
healthscore 



 create table user (id text primary key, external_user_id text, health_id text, first_name text, last_name text, email text, driver_license text, gender text, status text, application_type text, display_name text, mobile_phone text, office_phone text, home_phone text, date_of_birth text, language text, promotional_email text, created text, updated text, street_number text, street_name text, city text, country text, state text, zip_code text, appartment text, weight text, body_type text, pregnancy_status text, pregnancy_details text, disability_status text, disability_details text, coins text); 



 insert into user(id, appartment, application_type, body_type, city, country, created, date_of_birth, disability_details, disability_status, display_name, driver_license, email, external_user_id, first_name, gender, health_id, home_phone, language, last_name, mobile_phone, office_phone, pregnancy_details, pregnancy_status, promotional_email, state, status, street_name, street_number, updated, weight, zip_code, coins) values('28400000-8cf0-11bd-b23e-10b96e4ef00d','13','ap','slim','NYC','USA','2104-12-01','2104-12-01','123','False','sam','123','rfg@gmail.com','123','sam','male','123','123','eng','john','12','123','na','False','123@gmail.com','NY','na','nyc','123','2104-12-01','123','123', '50');




create keyspace query: create keyspace payl with replication = {‘class’: ‘SimpleStrategy’, ‘replication_factor’: 2} ;

create table users (id uuid primary key, external_id text, health_id text, first_name text, last_name text, email text, driver_license text, gender text, status text, application_type text, display_name text, mobile_phone text, office_phone text, home_phone text, date_of_birth date, language text, promotional_email text, created date, updated date, street_number int, street_name text, city text, country text, state text, zip_code text, appartment text, weight int, body_type text, pregnancy_status Boolean, pregnancy_details text, disability_status Boolean, disability_details text);



