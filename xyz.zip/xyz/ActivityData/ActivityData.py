from kafka import KafkaConsumer, KafkaClient
import avro.schema
import avro.io
import io
import json
from cqlengine import columns
from cqlengine.models import Model

# To consume messages
consumer = KafkaConsumer('ActivityDataTopic',
						 bootstrap_servers=['10.246.65.82:9092'])

# To send messages synchronously
kafka = KafkaClient('10.246.65.82:9092')

activity_schema_path="activity.avsc"
activity_schema = avro.schema.parse(open(activity_schema_path).read())

#using the person model from earlier:
class Activity(Model):
	id = columns.UUID(primary_key=True)
	activity_category = columns.Text()
	activity_id = columns.Text()
	activity_type = columns.Text()
	calories = columns.Text()
	created = columns.DateTime()
	distance = columns.Text()
	duration = columns.Text()
	eventId = columns.Text()
	eventType = columns.Text()
	external_id = columns.Text()
	intensity = columns.Text()
	optType = columns.Text()
	source = columns.Text()
	start_time = columns.DateTime()
	updated = columns.DateTime()



for msg in consumer:
	bytes_reader = io.BytesIO(msg.value)
	decoder = avro.io.BinaryDecoder(bytes_reader)
	reader = avro.io.DatumReader(activity_schema)
	activity = reader.read(decoder)

	act = Activity(
		activity_category=activity['activity_category'],
		activity_id=activity['activity_id'],
		activity_type=activity['activity_type'],
		calories=activity['calories'],
		created=activity['created'],
		distance=activity['distance'],
		duration=activity['duration'],
		eventId=activity['eventId'],
		eventType=activity['eventType'],
		external_id=activity['external_id'],
		intensity=activity['intensity'],
		optType=activity['optType'],
		source=activity['source'],
		start_time=activity['start_time'],
		updated=activity['updated']
		)
	act.save()

	print json.dumps(activity, indent=4, sort_keys=True)
	print "save activity data>>"


